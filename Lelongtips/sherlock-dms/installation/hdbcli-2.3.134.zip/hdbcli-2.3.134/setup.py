import shutil
import os
import sys
import ctypes
import sysconfig

try:
    import setuptools
    from setuptools import setup, Extension
    from setuptools.command.build_ext import build_ext as _build_ext
    have_setuptools = True
except ImportError:
    import distutils
    from distutils.core import setup, Extension
    from distutils.command.build_ext import build_ext as _build_ext
    have_setuptools = False

from distutils.errors import DistutilsPlatformError

class build_ext(_build_ext):
    _py_limited_api = False

    def _doesload(self, ext):
        src = os.path.join('ext', self.get_ext_filename(ext.name))
        try:
            dll = ctypes.pydll.LoadLibrary(src)
            del dll
        except:
            return False
        return True

    def _copy_ext(self, ext):
        src = os.path.join('ext', self.get_ext_filename(ext.name))
        tgt = self.get_ext_fullpath(ext.name)
        shutil.copyfile(src, tgt)

    def _have_compiled_ext(self, ext):
        src = os.path.join('ext', self.get_ext_filename(ext.name))
        if src.endswith('pyhdbcli.pyd') and os.name == 'nt' and sys.version_info[0] == 3:
            return False
        return os.path.isfile(src)

    def get_ext_filename(self, fullname):
        if sys.version_info[0] == 2:
            return _build_ext.get_ext_filename(self, fullname)
        fullname = super(build_ext, self).get_ext_filename(fullname)
        if self._py_limited_api and '.abi3' not in fullname:
            so_ext = sysconfig.get_config_var('EXT_SUFFIX')
            fullname = fullname[:-len(so_ext)]
            fullname += '.abi3' + (sysconfig.get_config_var('SHLIB_SUFFIX') if not os.name == 'nt' else '.pyd')
        return fullname

    def build_extension(self, ext):
        self._py_limited_api = False
        if self._have_compiled_ext(ext) and self._doesload(ext):
            self._copy_ext(ext)
        elif sys.version_info[0] == 3:
            # Fallback to installing the abi3.so driver on 3.4+
            if sys.version_info[1] < 4:
                raise DistutilsPlatformError("Compatible extension not found. The abi3 driver is only supported on Python >= 3.4.")
            if not have_setuptools:
                raise DistutilsPlatformError("setuptools is required to install the abi3 driver.")
            ext.py_limited_api = True
            self._py_limited_api = True
            if self._have_compiled_ext(ext) and self._doesload(ext):
                self._copy_ext(ext)
            else:
                raise DistutilsPlatformError("A compatible abi3 driver could not be found.")
        else:
            raise DistutilsPlatformError("Compatible extension not found.")

setupargs = dict(
    name = 'hdbcli',
    version = '2.3.134',
    packages = ['hdbcli'],
    ext_modules = [Extension('pyhdbcli', [])],
    cmdclass = {'build_ext':build_ext}
)

setup(**setupargs)
